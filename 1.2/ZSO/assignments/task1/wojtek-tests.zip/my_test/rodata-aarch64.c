const long long answer = 42;
