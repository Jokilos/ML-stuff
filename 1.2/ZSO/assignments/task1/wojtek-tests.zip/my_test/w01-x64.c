#include <stdio.h>

int f();

int real_main(void) {
    printf("%d\n", f());
    return 0;
}

