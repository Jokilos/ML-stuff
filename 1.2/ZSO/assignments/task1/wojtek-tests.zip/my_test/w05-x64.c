#include <stdio.h>

int f(int);

int real_main(void) {
    printf("%d\n", f(10));
    return 0;
}

