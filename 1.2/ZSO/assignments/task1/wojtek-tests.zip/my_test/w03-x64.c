#include <stdio.h>

int f(int);

int real_main(void) {
    printf("%d\n", f(0));
    return 0;
}

