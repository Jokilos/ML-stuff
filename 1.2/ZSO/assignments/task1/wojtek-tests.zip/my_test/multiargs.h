#ifndef MULTIARGS_H
#define MULTIARGS_H

#define I1      0x13
#define L1      0x413L
#define LL1     0x4647LL
#define U1      0xf3U
#define UL1     0x2e3LU
#define ULL1    0xf6f7LLU
#define LL_RET  0xedLL
#endif
