int f() {
    int x = 1 + 1;
    int y = 3;
    int z = x + y;

    z += 10;

    return z;
}