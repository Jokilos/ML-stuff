Place `converter` file or symlink in a directory.
Run

```
./run.sh
```

The script compiles the test and ground-truth test 
and compares the outputs.