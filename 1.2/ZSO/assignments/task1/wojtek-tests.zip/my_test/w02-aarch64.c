extern int x;

int f(){
    x += 10;
    return x;
}
