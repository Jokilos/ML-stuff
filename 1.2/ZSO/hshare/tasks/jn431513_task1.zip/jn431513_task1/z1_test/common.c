extern int real_main(void);

int main(void) {
	return real_main();
}
