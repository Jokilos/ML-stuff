source ./venv/bin/activate
cd z1_test
./run.sh
