sudo apt install python3.11-venv gcc-aarch64-linux-gnu -y
python3 -m venv venv
source ./venv/bin/activate
pip install -r requirements.txt
